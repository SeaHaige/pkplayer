<?php
return array (
  'tv6_com_1' => 0,
  'tv6_com_6' => 7,
  'tv6_com_5' => 6,
  '26274abb1a99d3533acb28f73ee4dad6_23' => 6,
  '11a1d5ac22763b6ee11abf4538da2d01_23' => 6,
  '5f3d68693435f1a73779ca867972b266_5' => 6,
  'f1017ff531d15469b5b7ea8d177f348a_5' => 6,
  'bafddc1bc639e3255c0aae5e898fcf9e_5' => 6,
);