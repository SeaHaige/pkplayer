<?php

return array (
  0 => 
  array (
    'name' => 'mode',
    'title' => '模式',
    'type' => 'radio',
    'content' => 
    array (
      'fixed' => '固定',
      'random' => '每次随机',
      'daily' => '每日切换',
    ),
    'value' => 'random',
    'rule' => 'required',
    'msg' => '',
    'tip' => '根据自身爱好选择',
    'ok' => '',
    'extend' => '',
  ),
  1 => 
  array (
    'name' => 'image',
    'title' => '固定背景图',
    'type' => 'image',
    'content' => 
    array (
    ),
    'value' => 'upload/addon/20180419/60766c894977757d436b641f97356b40.jpg',
    'rule' => 'required',
    'msg' => '',
    'tip' => '请选择文件...',
    'ok' => '',
    'extend' => '',
  ),
);
